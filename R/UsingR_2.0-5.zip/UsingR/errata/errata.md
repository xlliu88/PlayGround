# Errata for *Using R for Introductory Statistics*, second edition.


* Thanks to: William Kitto, Antelope Valley College for finding errors in the Solutions Manual (9.2 and 9.4).




